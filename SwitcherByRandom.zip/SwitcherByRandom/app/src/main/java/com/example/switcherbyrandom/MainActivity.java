package com.example.switcherbyrandom;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    private Button button1;
    private Button button2;
    private TextView names;
    private int repeat = 1;
    private boolean start_stop = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1 = findViewById(R.id.button1);
        names = findViewById(R.id.name1);
        button2 =(Button)findViewById(R.id.button2);

    }

    public void onButtonClickStop (View view) {
        start_stop = false;
    }

public void onButtonClickStart(View view) {
                           start_stop = true;

                           new Thread(new Runnable() {
                               @Override
                               public void run() {
                                   while (start_stop) {
                                       repeat++;
                                       switch (repeat){
                                           case 1 :
                                               names.setText("Victoria Egorova");
                                               break;
                                           case 2 :
                                               names.setText("Denys Doskochyskyi");
                                               break;
                                           case 3 :
                                               names.setText("Maxim Budzyn");
                                               break;
                                           case 4 :
                                               names.setText("Svyatoslav Trostynskyi");
                                               break;
                                           case 5 :
                                               names.setText("Vasyl Strashyvskyi");
                                               break;
                                           case 6 :
                                               names.setText("Maria Sapiy");

                                               repeat = 0;
                                               break;

                                       }
                                       try {
                                           Thread.sleep(40);
                                       } catch (InterruptedException e) {
                                           e.printStackTrace();
                                       }
                                   }
                               }
                           }).start();
                       }
                   }



