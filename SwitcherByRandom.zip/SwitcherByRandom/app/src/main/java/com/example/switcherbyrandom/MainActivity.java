package com.example.switcherbyrandom;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;


public class MainActivity extends AppCompatActivity
{
    private TextView names;
    private boolean start_stop = false;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        names = findViewById(R.id.name1);

    }
          /*  public static void main(String[] args)
            {
               String[] name;
                name = new String[6];
                name[0] = "Victoria Egorova";
                name[1] = "Denys Doskochyskyi";
                name[2] = "Maxim Budzyn";
                name[3] = "Svyatoslav Trostynskyi";
                name[4] = "Vasyl Strashyvskyi";
                name[5] = "Maria Sapiy";
                 String[] name =
                        {  "Victoria Egorova",
                           "Denys Doskochyskyi",
                           "Maxim Budzyn",
                           "Svyatoslav Trostynskyi",
                           "Vasyl Strashyvskyi",
                           "Maria Sapiy"      };
                name = new String[6];

            }   */
    public void onButtonClickStop (View view)
    {
        start_stop = false;
    }

public void onButtonClickStart(View view)
            {
                final String[] name =
                        {  "Victoria Egorova",
                                "Denys Doskochyskyi",
                                "Maxim Budzyn",
                                "Svyatoslav Trostynskyi",
                                "Vasyl Strashyvskyi",
                                "Maria Sapiy"      };

                start_stop = true;

                new Thread(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        while(start_stop)
                        {
                            Random random = new Random();
                            int i = random.nextInt(5)+1;
                            String result = (name[i]);
                            names.setText(result);
                            try
                            {
                                Thread.sleep(40);
                            }
                                catch (InterruptedException e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }
                }).start();

            }
}



