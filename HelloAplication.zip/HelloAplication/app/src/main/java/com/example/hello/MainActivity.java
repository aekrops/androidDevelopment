package com.example.hello;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView Text;
    private Button MyButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    public void onButtonClick(View view) {
        TextView textView = (TextView) findViewById(R.id.text2);
        textView.setText("Svyatoslav Trostynskyi");
        TextView textView1 = (TextView) findViewById(R.id.textView3);
        textView1.setText("");
    }


}